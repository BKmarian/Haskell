module Principal where

import Arbore

main :: IO [Int]
main = undefined
